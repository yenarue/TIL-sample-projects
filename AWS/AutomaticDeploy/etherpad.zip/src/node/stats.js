var measured = require('measured')

module.exports = measured.createCollection();